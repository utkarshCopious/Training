package com.training.exceptions.exceptions;

/**
 * @author Utkarsh Awasthi
 **/

public class ProcessRuntimeErrorException extends RuntimeException {
    private static final long serialVersionUID = 2L;

}
