//package com.copious.training.RepInterface;
//
//import com.copious.training.ProModel.employee;
//
//import java.io.IOException;
//import java.util.List;
///**
// * @author Utkarsh Awasthi
// **/
//public interface repoInterface {
//    List<employee> getEmployee() throws IOException;
//}
